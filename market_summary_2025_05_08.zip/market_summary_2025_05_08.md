
# Taiwan Stock Market Daily Report
**Date: May 8, 2025 (Thursday)**

---

## 1. Market Overview
The TAIEX closed at **20,546.5**, up **23.9 points (+0.1%)**, hovering near its 5-day moving average with unchanged volume of NT$276.45 billion, reflecting a cautious sentiment among investors.

The OTC Index closed at **219.6**, down **1.9 points (-0.8%)**, showing weakness in small and mid-cap stocks.

---

## 2. Institutional Investors – Net Buy/Sell
| Institution | Net Buy/Sell (NT$ Billion) | Notes |
|-------------|----------------------------|-------|
| Foreign     | +136.5                     | Buying into large-cap leaders like TSMC, Hon Hai, and UMC |
| Investment Trust | -29.0                | Fourth consecutive day of selling, indicating risk aversion |
| Margin Trading | +20.4                  | Retail investors continue to add leverage |
| Short Selling | -4.1                    | Lowered, indicating reduced bearish sentiment |
| Securities Lending | -66,262 contracts   | Foreign institutions maintaining large-scale short positions |

---

## 3. Strong Sectors
- **IC Design**: Alchip (3661), eMemory (3529) continued to surge
- **AI Servers**: Wistron (3231), Chicony Power (3017) driven by GPU/AI demand
- **Revenue Breakout Stocks**: Accton (6139), FerroTec (1560)
- **Defense/Drone**: Thunder Tiger (8033), AIDC (2634)

---

## 4. Technical Analysis
- TAIEX reclaimed 5-day moving average, but volume remains weak
- KD: Golden cross; MACD histogram turned positive
- Market remains in rebound phase, with resistance at 20,650

---

## 5. Top Net Buys by Institution

### Foreign Investors
1. Hon Hai (2317): +20,800 contracts
2. UMC (2303): +14,300 contracts
3. Winbond (2344): +13,600 contracts

### Investment Trusts
1. Fortune Electric (1519): +1,279 contracts
2. Delta Electronics (2308): +1,181 contracts
3. Taipower (8926): +1,053 contracts

---

## 6. Market Outlook
- Without increased trading volume, the index is likely to remain range-bound
- Watch for turning points in foreign futures net long and securities lending trends
- Upcoming US CPI next week could reshape Fed rate expectations

---

**Data sources: TWSE, CMoney, Bloomberg, Fubon Securities**
