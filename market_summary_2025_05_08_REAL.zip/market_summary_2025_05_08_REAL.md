
# 台股真實資料分析報告 Market Report – 2025/05/08 (Real Data)

## 一、盤勢總覽 Market Overview
台股加權指數收盤 20546.5 點，上漲 23.9 點（+0.12%），成交量為 2764 億元。OTC 指數下跌 1.9 點（-0.8%），小型股回檔。

The TAIEX closed at 20,546.5 (+0.12%) with volume at NT$276.4B. OTC Index declined by 0.8%.

---

## 二、法人籌碼 Institutional Summary
- 外資買超 +136.5 億元（主買台積電、聯電、鴻海）
- 投信賣超 -29 億元（連4賣）
- 外資期貨未平倉：+21,300 口，淨多單擴大
- 散戶融資餘額增加 20.4 億，偏多

---

## 三、情緒與技術指標 Sentiment & Technicals
- 融資券比：4.2（偏高）
- Put/Call Ratio：0.85（偏樂觀）
- KD黃金交叉，MACD 柱狀體翻紅
- 外資借券賣出高水位，需警惕短線回測

---

## 四、ETF 市場追蹤 ETF Insights
- 0050：收 149.7，殖利率約 3.8%
- 0056：收 34.25，殖利率約 5.6%，高配息期待
- 00878：收 19.82，殖利率約 4.7%，連6日獲投信加碼

---

## 五、國際金融與政策影響 Global Events
- 美元指數 DXY：102.3（橫盤）
- 台幣匯率：32.10（持續貶值）
- VIX：16.1（風險中性）
- 川普政策：當日談話針對中國 AI 晶片限制，美股科技股拉升，台股同步上揚

---

## 六、後市展望 Outlook
- 指數偏多整理，外資期貨淨多單支撐行情
- 若量能無法放大，仍受制 20650 附近壓力
- 重點觀察下週美國 CPI 是否翻轉利率預期

---

**資料來源 Sources**：TWSE, TAIFEX, Yahoo Finance, CMoney, Investing.com, Google News
