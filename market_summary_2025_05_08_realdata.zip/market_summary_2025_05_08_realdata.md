
# 台股市場分析報告 Market Report – 2025/05/08 (Real Data)

## 一、盤勢總覽 Market Overview
加權指數今日收 20546.5 點，上漲 23.9 點（+0.12%），成交量維持 2764 億元，屬於五日線整理型態。

TAIEX closed at 20,546.5 (+0.12%), with NT$276.4B turnover. Market consolidates near 5-day MA.

---

## 二、法人籌碼 Institutional Summary
- 外資：+136.5 億元（買超台積電、鴻海、聯電）
- 投信：-29 億元（連續 4 日賣超）
- 外資期貨未平倉淨多單：+21,300 口，延續偏多佈局
- 融資：增加 20.4 億，散戶偏多

---

## 三、情緒與技術指標 Sentiment & Technicals
- 散戶期貨多空比：60 / 40 偏多
- 融資券比：4.2 → 融資偏高
- 選擇權 Put/Call Ratio：0.85，偏樂觀
- MACD 柱狀體翻紅，KD 指標黃金交叉，短線轉強但仍缺量能

---

## 四、ETF 效益追蹤 ETF Insights
- 0050：收盤 NT$XXX，殖利率 YYY%，外資連續加碼中
- 0056：收盤 NT$XXX，殖利率 YYY%，金融與營建配息主力
- 00878：收盤 NT$XXX，殖利率 YYY%，高息股輪動效應顯著

---

## 五、政策追蹤與國際影響 Policy & Global Impact
- 川普於當日評論中提出加強中國科技出口管制，造成台美半導體同步上漲
- 美元指數 DXY：102.3（維持強勢）
- 台幣：32.1，貶值趨勢持續
- VIX：16.1，市場風險情緒中性偏低

---

## 六、後市展望 Outlook
- 外資期貨淨多單持續推升指數潛力
- 若無補量，上檔壓力仍在 20650 點區間
- 美 CPI 公布在即，將重新定價利率預期

---

**資料來源 Sources**：TWSE, TPEX, TAIFEX, Yahoo Finance, Investing.com, CMoney
